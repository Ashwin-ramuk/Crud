class Offer < ApplicationRecord
	belongs_to :customer, -> { where active: true },
                        dependent: :destroy
end
