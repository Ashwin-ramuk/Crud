Paperclip.options[:content_type_mappings] = {
  :jpg => "image/jpeg",
  :png => "image/png",
  :gif => "image/gif"
}