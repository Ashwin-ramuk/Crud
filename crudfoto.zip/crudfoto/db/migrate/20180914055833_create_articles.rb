class CreateArticles < ActiveRecord::Migration[5.2]
  def change
    create_table :articles do |t|
      t.string :Name
      t.date :DOB
      t.string :Address
      t.integer :phone_num

      t.timestamps
    end
  end
end
