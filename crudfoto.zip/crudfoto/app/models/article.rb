class Article < ApplicationRecord
	has_attached_file :image
	do_not_validate_attachment_file_type :image
	#validate_media_type: false
	  validates :Name, presence: true,
                    length: { minimum: 5 }

end
